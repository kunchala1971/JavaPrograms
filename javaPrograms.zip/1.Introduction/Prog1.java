class Prog1
{
public static void main(String args[])
{
    System.out.println("Hello Java World!");
    System.out.println("KKCC INFO SYSTEMS");
    System.out.println("Ongole");    
}
}